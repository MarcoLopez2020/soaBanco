<?php
include_once("conexion.php");

class crudB
{
    public static function buscarEstudiante($cedula)
    {
        $objeto = new Conexion();
        $conectar = $objeto->conectar();

        $select = "SELECT * FROM estudiante WHERE cedula = :cedula";

        $resultado = $conectar->prepare($select);
        $resultado->bindParam(':cedula', $cedula, PDO::PARAM_STR);
        $resultado->execute();

        $data = $resultado->fetch(PDO::FETCH_ASSOC);

        if ($data) {
            echo json_encode($data);
        } else {
            echo json_encode("No se encontraron resultados para la cédula proporcionada.");
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (isset($_GET['cedula'])) {
        $cedula = $_GET['cedula'];
        crudB::buscarEstudiante($cedula);
    } else {
        echo json_encode("Por favor, proporcione una cédula para buscar.");
    }
} else {
    http_response_code(405); // Método no permitido
    echo json_encode("Método no permitido para buscar.");
}
?>
