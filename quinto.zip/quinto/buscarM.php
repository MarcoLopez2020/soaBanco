<?php
include_once("conexion.php");

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['nombre_materia'])) {
    $nombreMateria = $_GET['nombre_materia'];

    $objeto = new Conexion();
    $conectar = $objeto->Conectar();

    // Realiza una consulta SQL para obtener los estudiantes relacionados con la materia
    $consulta = "SELECT estudiante.cedula, estudiante.nombre, estudiante.apellido, estudiante.direccion, estudiante.telefono
                 FROM estudiante
                 INNER JOIN materias ON estudiante.cedula = materias.estudiante_id
                 WHERE materias.nombre = :nombreMateria";

    $resultado = $conectar->prepare($consulta);
    $resultado->bindParam(':nombreMateria', $nombreMateria);
    $resultado->execute();

    $data = $resultado->fetchAll(PDO::FETCH_ASSOC);

    if ($data) {
        echo json_encode($data);
    } else {
        echo json_encode("No se encontraron estudiantes para la materia: $nombreMateria");
    }
} else {
    http_response_code(405); // Método no permitido
    echo json_encode("Método no permitido para buscar estudiantes por materia.");
}
?>
