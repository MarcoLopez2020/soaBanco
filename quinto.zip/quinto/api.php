<?php

include_once "seleccionar.php";
include_once "guardar.php";
include_once "delete.php";
include_once "actualizar.php";


$opc =$_SERVER["REQUEST_METHOD"];
switch ($opc){
    case "GET":
  //  $resultado="tu estas en un GET";
    crud::obtenerEstudiantes();
    break;
   // echo($resultado);
    case "POST":
    crudG::guardarEstudiante();
    break;
    case "DELETE":
    $var = $_GET["cedula"];
    crudE:: eliminarEstudiante($var);
    break;
    case "PUT":
      crudA::editarEstudiante();
    break;


}
?>

